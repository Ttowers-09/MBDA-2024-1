INSERT INTO auditoria(idauditoria, fecha, accion, nombre, categoria_codigo, evaluacion_a_omes)
VALUES ('4', '05,12,24', '3', 'Nombre', 'HG875', '2' );

INSERT INTO auditoria(idauditoria, fecha, accion, nombre, categoria_codigo, evaluacion_a_omes)
VALUES ('1', '15,11,22', '9', 'Nombre2', 'HAT54', '3' );

INSERT INTO auditoria(idauditoria, fecha, accion, nombre, categoria_codigo, evaluacion_a_omes)
VALUES ('4', '22,05,99', '5', 'Nombre3', 'KST02', '1' );


INSERT INTO ROPA(talla, material, color, articulo_id)
VALUES('12', 'Algodon', 'BLACK', 'WSDF45ASDF');

INSERT INTO ROPA(talla, material, color, articulo_id)
VALUES('41', 'Lino', 'RED', 'JABDS6501');

INSERT INTO ROPA(talla, material, color, articulo_id)
VALUES('24', 'Franela', 'BLUE', 'JABST5544');

INSERT INTO evaluacion (a_omes, tid, nid, fecha, descripcion, reporte, resultado, respuestas)
VALUES ('5', '6', '210595', '25,12,98', 'Descripcion  1', 'reporte  1', 'Resultado  1', 'Respuestas evaluacion 1');

INSERT INTO evaluacion (a_omes, tid, nid, fecha, descripcion, reporte, resultado, respuestas)
VALUES ('9', '4', '51036', '02,12,24', 'Descripcion  2', 'reporte  2', 'Resultado  2', 'Respuestas evaluacion 2');

INSERT INTO evaluacion (a_omes, tid, nid, fecha, descripcion, reporte, resultado, respuestas)
VALUES ('2', '0', '41036', '19,02,24', 'Descripcion  3', 'reporte  3', 'Resultado 3', 'Respuestas evaluacion 3');

DELETE FROM articulo;

DELETE FROM auditoria;

DELETE FROM califica;

DELETE FROM CARACTERISTICAS;

DELETE FROM categoria;

DELETE FROM evaluacion;

DELETE FROM parecedero;

DELETE FROM respuestas;

DELETE FROM ropa;

DELETE FROM universidad;

DELETE FROM usuario;

